
$(document).ready(function() {
    $('#reg_form').bootstrapValidator({
        // To use feedback icons, ensure that you use Bootstrap v3.1.0 or later
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {

           uname: {
                validators: {
                        stringLength: {
                        min: 6,
                    },
                        notEmpty: {
                        message: 'Minimal 6 karakter!'
                    }
                }
            },

            nama_dpn: {
                validators: {
                        stringLength: {
                        min: 2,
                    },
                        notEmpty: {
                        message: 'Masukkan nama depan anda!'
                    }
                }
            },
             nama_blkg: {
                validators: {
                     stringLength: {
                        min: 2,
                    },
                    notEmpty: {
                        message: 'Masukkan nama belakang anda!'
                    }
                }
            },

            ptn: {
                validators: {
                     stringLength: {
                        min: 3,
                    },
                    notEmpty: {
                        message: 'Masukkan Perguruan tinggi!'
                    }
                }
            },
           
            hp: {
                validators: {
                    stringLength: {
                        min: 12,
                    },
                    notEmpty: {
                        message: 'Masukkan nomer hp anda!'
                    }
                }
            },

            address: {
                validators: {
                     stringLength: {
                        min: 8,
                    },
                    notEmpty: {
                        message: 'Please supply your street address'
                    }
                }
            },

            city: {
                validators: {
                     stringLength: {
                        min: 4,
                    },
                    notEmpty: {
                        message: 'Please supply your city'
                    }
                }
            },

            state: {
                validators: {
                    notEmpty: {
                        message: 'Please select your state'
                    }
                }
            },
            zip: {
                validators: {
                    notEmpty: {
                        message: 'Please supply your zip code'
                    },
                    zipCode: {
                        country: 'US',
                        message: 'Please supply a vaild zip code'
                    }
                }
            },

        comment: {
                validators: {
                      stringLength: {
                        min: 10,
                        max: 200,
                        message:'Please enter at least 10 characters and no more than 200'
                    },
                    notEmpty: {
                        message: 'Please supply a description about yourself'
                    }
                    }
                 }, 

        email: {
                validators: {
                    notEmpty: {
                        message: 'Masukkan email anda!'
                    },
                    emailAddress: {
                        message: 'Email tidak valid!'
                    }
                }
            },
                    
    // password: {
    //         validators: {
    //             identical: {
    //                 field: 'confirmPassword',
    //                 message: 'Confirm your password below - type same password please'
    //             }
    //         }
    //     },

    //     confirmPassword: {
    //         validators: {
    //             identical: {
    //                 field: 'password',
    //                 message: 'The password and its confirm are not the same'
    //             }
    //         }
    //      },
            
            
            }
        })
        
    
        .on('success.form.bv', function(e) {
            $('#success_message').slideDown({ opacity: "show" }, "slow") // Do something ...
                $('#reg_form').data('bootstrapValidator').resetForm();

            // Prevent form submission
            e.preventDefault();

            // Get the form instance
            var $form = $(e.target);

            // Get the BootstrapValidator instance
            var bv = $form.data('bootstrapValidator');

            // Use Ajax to submit form data
            $.post($form.attr('action'), $form.serialize(), function(result) {
                console.log(result);
            }, 'json');
        });
});
