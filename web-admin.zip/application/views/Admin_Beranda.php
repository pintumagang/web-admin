   <div class="row">
            <div class="col-xs-6 col-md-3 productbox">
              <a href="#" class="thumbnail clearfix">
                <img src="<?php echo base_url('assets\images\icons\admin.png'); ?>" width="120px" height="80px" class="img-responsive">
                <div class="producttitle">Admin</div>
              </a>
            </div>

            <div class="col-xs-6 col-md-3 productbox">
              <a href="#" class="thumbnail clearfix">
                <img src="<?php echo base_url('assets\images\icons\mahasiswa.png'); ?>" width="120px" height="80px" class="img-responsive">
                <div class="producttitle">Mahasiswa</div>
              </a>
            </div>
          </div>
    <div class="row">  
            <div class="col-xs-6 col-md-3 productbox">
              <a href="#" class="thumbnail clearfix">
                <img src="<?php echo base_url('assets\images\icons\company.png'); ?>" width="120px" height="80px" class="img-responsive">
                <div class="producttitle">Perusahaan</div>
              </a>
            </div> 

            <div class="col-xs-6 col-md-3 productbox">
              <a href="#" class="thumbnail clearfix">
                <img src="<?php echo base_url('assets\images\icons\list.png'); ?>" width="120px" height="80px" class="img-responsive">
                <div class="producttitle">Lowongan</div>
              </a>
            </div> 

    </div>
    