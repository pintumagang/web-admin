   <div class="row">
            <div class="col-xs-4 col-md-3 productbox">
              <a href="<?php echo site_url('Admin/View_Admin')?>?module=Admin" class="thumbnail clearfix">
                <img src="<?php echo base_url('assets\images\icons\admin.png'); ?>" width="120px" height="80px" class="img-responsive">
                <div class="producttitle">Admin</div>
              </a>
            </div>
            <div class="col-xs-4 col-md-3 productbox">
              <a href="<?php echo site_url('Admin/View_Mahasiswa')?>?module=Mahasiswa" class="thumbnail clearfix">
                <img src="<?php echo base_url('assets\images\icons\mahasiswa.png'); ?>" width="120px" height="80px" class="img-responsive">
                <div class="producttitle">Mahasiswa</div>
              </a>
            </div>
          
          <div class="col-xs-4 col-md-3 productbox">
              <a href="<?php echo site_url('Admin/View_Lowongan')?>?module=Lowongan" class="thumbnail clearfix">
                <img src="<?php echo base_url('assets\images\icons\list.png'); ?>" width="120px" height="80px" class="img-responsive">
                <div class="producttitle">Program Studi</div>
              </a>
          </div>
    </div>
    <div class="row">  
            <div class="col-xs-4 col-md-3 productbox">
              <a href="<?php echo site_url('Admin/View_Perusahaan')?>?module=Perusahaan" class="thumbnail clearfix">
                <img src="<?php echo base_url('assets\images\icons\company.png'); ?>" width="120px" height="80px" class="img-responsive">
                <div class="producttitle">Perusahaan</div>
              </a>
            </div> 

            <div class="col-xs-4 col-md-3 productbox">
              <a href="<?php echo site_url('Admin/View_Lowongan')?>?module=Lowongan" class="thumbnail clearfix">
                <img src="<?php echo base_url('assets\images\icons\list.png'); ?>" width="120px" height="80px" class="img-responsive">
                <div class="producttitle">Lowongan</div>
              </a>
            </div> 

            <div class="col-xs-4 col-md-3 productbox">
              <a href="<?php echo site_url('Admin/View_Lowongan')?>?module=Lowongan" class="thumbnail clearfix">
                <img src="<?php echo base_url('assets\images\icons\gallery.png'); ?>" width="120px" height="80px" class="img-responsive">
                <div class="producttitle">Slider</div>
              </a>
            </div> 
    </div>
    