
<div class="judul">
    <h3 align="center">Data User Mahasiswa</h3>
</div>
<div id="toolbar" class="btn-group">
</div>
<div >
<table id="myTable" class="table table-striped table-bordered table-hover">
     <thead>
      <tr>
        <th width="40">No</th>
        <th>Nama Mahasiswa</th>
        <th>Username</th>
        <th>Email</th>
        <th>Perguruan Tinggi</th>
        <th>No. Hp</th>
        <th>Last Login</th>
        <th><button onclick="document.getElementById('modal-wrapper').style.display='block'" type="button" class="btn btn-default Tambah">
        <i class="glyphicon glyphicon-plus">Tambah</i>
    </button></th>
      </tr>
      </thead>
            <tbody>
     <?php 
      foreach ($mahasiswa as $mhs) {
        $id_user  = $mhs['id_user'];
        $id_mhs   = $mhs['id_mhs'];
        $nama_depan = $mhs['nama_depan'];
        $nama_belakang = $mhs['nama_belakang'];
        $username   = $mhs['username'];
        $email_user  = $mhs['email_user'];
        $perguruan_tinggi = $mhs['perguruan_tinggi'];
        $hp = $mhs['hp'];
        $last_login = $mhs['last_login'];

      echo"
      <tr>
        <td> $id_mhs </td>
        <td> $nama_depan $nama_belakang</td>
        <td> $username</td>
        <td> $email_user</td>
        <td> $perguruan_tinggi</td>
        <td> $hp</td>
        <td> $last_login</td> 
        <td> ";
        ?>
        
          
          <button onclick="document.getElementById('modal-wrapper-edit<?php echo $id_user?>').style.display='block'" type="button" class="btn btn-default Tambah">
              <i class="glyphicon glyphicon-pencil"></i>
          </button>

        <div id="modal-wrapper-edit<?php echo $id_user?>" class="modal">

      <div class="modal-dialog-lg">

                    <!-- Modal content-->
                    <div class="modal-content">
                        <div class="modal-header">
                            <span onclick="document.getElementById('modal-wrapper-edit<?php echo $id_user?>').style.display='none'" class="close" title="Close PopUp">&times;</span>
                        </div>
                        <div class="modal-body" >
                            <div class="bootstrap-iso">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="center-block">
                                            <form class="form-horizontal bv-form" action="http://www.lisenme.com/demo/boostrab/index.php" method="post" id="reg_form" novalidate="novalidate">
    <fieldset>
      
      <!-- Form Name -->
      <legend> Personal Information </legend>
    
      <!-- Text input-->
      
      <div class="form-group has-feedback">
        <div class="col-md-6  inputGroupContainer">
          <div class="input-group">
            <input name="first_name" placeholder="Nama Depan" class="form-control" type="text" data-bv-field="first_name"><i class="form-control-feedback" data-bv-icon-for="first_name" style="display: none;"></i>
          </div>
        </div>
      </div>
      
      <!-- Text input-->
      
      <div class="form-group has-feedback">
        <label class="col-md-4 control-label">Last Name</label>
        <div class="col-md-6  inputGroupContainer">
          <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
            <input name="last_name" placeholder="Last Name" class="form-control" type="text" data-bv-field="last_name"><i class="form-control-feedback" data-bv-icon-for="last_name" style="display: none;"></i>
          </div>
        </div>
      </div>
      
    
      <!-- Text input-->
      
      <div class="form-group has-feedback">
        <label class="col-md-4 control-label">Phone</label>
        <div class="col-md-6  inputGroupContainer">
          <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-earphone"></i></span>
            <input name="phone" placeholder="(000)000-0000" class="form-control" type="text" data-bv-field="phone"><i class="form-control-feedback" data-bv-icon-for="phone" style="display: none;"></i>
          </div>
        </div>
      </div>
      
      <!-- Text input-->
      
      <div class="form-group has-feedback">
        <label class="col-md-4 control-label">Address</label>
        <div class="col-md-6  inputGroupContainer">
          <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span>
            <input name="address" placeholder="Address" class="form-control" type="text" data-bv-field="address"><i class="form-control-feedback" data-bv-icon-for="address" style="display: none;"></i>
          </div>
        </div>
      </div>
      
      <!-- Text input-->
      
      <div class="form-group has-feedback">
        <label class="col-md-4 control-label">City</label>
        <div class="col-md-6  inputGroupContainer">
          <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span>
            <input name="city" placeholder="city" class="form-control" type="text" data-bv-field="city"><i class="form-control-feedback" data-bv-icon-for="city" style="display: none;"></i>
          </div>
        </div>
      </div>
      
      <!-- Select Basic -->
      
    
      <!-- Text input-->
      
      <div class="form-group has-feedback">
        <label class="col-md-4 control-label">Zip Code</label>
        <div class="col-md-6  inputGroupContainer">
          <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span>
            <input name="zip" placeholder="Zip Code" class="form-control" type="text" data-bv-field="zip"><i class="form-control-feedback" data-bv-icon-for="zip" style="display: none;"></i>
          </div>
        </div>
      </div>
      
        <!-- Text area -->
      
      <div class="form-group has-feedback">
        <label class="col-md-4 control-label">About </label>
        <div class="col-md-6  inputGroupContainer">
          <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-pencil"></i></span>
            <textarea class="form-control" name="comment" placeholder="About " data-bv-field="comment"></textarea><i class="form-control-feedback" data-bv-icon-for="comment" style="display: none;"></i>
          </div>
        </div>
      </div>
      
     
       </fieldset>
        <legend> Account information </legend>
        <fieldset>
        <!-- Text input-->
      <div class="form-group has-feedback">
        <label class="col-md-4 control-label">E-Mail</label>
        <div class="col-md-6  inputGroupContainer">
          <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
            <input name="email" placeholder="E-Mail Address" class="form-control" type="text" data-bv-field="email"><i class="form-control-feedback" data-bv-icon-for="email" style="display: none;"></i>
          </div>
        </div>
      </div>
      
    
        <div class="form-group has-feedback">
            <label for="password" class="col-md-4 control-label">
                    Password
                </label>
                <div class="col-md-6  inputGroupContainer">
                <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span>
            <input class="form-control" id="userPw" type="password" placeholder="password" name="password" data-minlength="5" data-error="some error" required="" data-bv-field="password"><i class="form-control-feedback" data-bv-icon-for="password" style="display: none;"></i>
                <span class="glyphicon form-control-feedback"></span>
                <span class="help-block with-errors"></span>
                </div>
             </div>
        </div>
     
        <div class="form-group has-feedback">
            <label for="confirmPassword" class="col-md-4 control-label">
                   Confirm Password
                </label>
                 <div class="col-md-6  inputGroupContainer">
                <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span>
            <input class="form-control {$borderColor}" id="userPw2" type="password" placeholder="Confirm password" name="confirmPassword" data-match="#confirmPassword" data-minlength="5" data-match-error="some error 2" required="" data-bv-field="confirmPassword"><i class="form-control-feedback" data-bv-icon-for="confirmPassword" style="display: none;"></i>
                <span class="glyphicon form-control-feedback"></span>
                <span class="help-block with-errors"></span>
                 </div>
            s</div>
        </div>
     
  
      <!-- Button -->
      <div class="form-group">
        <label class="col-md-4 control-label"></label>
        <div class="col-md-4">
          <button type="submit" class="btn btn-warning">Send <span class="glyphicon glyphicon-send"></span></button>
        </div>
      </div>
    </fieldset>
  <input type="hidden" value=""></form>
                                        </div>
                                    </div>
                                </div>
                            </div>



                        </div>
                    </div>
                </div>

     </div> 

          <a href="<?php echo site_url('Admin/deletemahasiswa/'.$id_user)?>" >
          <button onclick="return confirm ('Apakah anda yakin?')" type="button" class="btn btn-default">
              <i class="glyphicon glyphicon-trash"></i>
          </button></a>
          
        </td>
       
      </tr>
     <?php }
     ?>
      </tbody>
    </table>
  </div>  

<div id="modal-wrapper" class="modal">

                         <div class="modal-dialog-lg">

                          <!-- Special version of Bootstrap that only affects content wrapped in .bootstrap-iso -->
    <link rel="stylesheet" href="https://formden.com/static/cdn/bootstrap-iso.css" />

    <!--Font Awesome (added because you use icons in your prepend/append)-->
    <link rel="stylesheet" href="https://formden.com/static/cdn/font-awesome/4.4.0/css/font-awesome.min.css" />

    <!-- Inline CSS based on choices in "Settings" tab -->
    <style>.bootstrap-iso .formden_header h2, .bootstrap-iso .formden_header p, .bootstrap-iso form{font-family: Arial, Helvetica, sans-serif; color: black}.bootstrap-iso form button, .bootstrap-iso form button:hover{color: white !important;} .asteriskField{color: red;}</style>

                    <!-- Modal content-->
                    <div class="modal-content">
                        <div class="modal-header">
                            <span onclick="document.getElementById('modal-wrapper').style.display='none'" class="close" title="Close PopUp">&times;</span>
                            <h4 class="modal-title">Tambah Mahasiswa</h4>
                        </div>
                        <div class="modal-body" >
                            <div class="bootstrap-iso">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="center-block">
                                            <form id="tambahmahasiswa" method="post" action="<?php echo site_url("Admin/tambahmahasiswa")?>">

                                                <div class="form-group ">
                                                    <input class="form-control" id="validationCustom01" type="text" id="uname" type="text" placeholder="Username" name="uname" required />
                                                </div>

                                                <div class="form-group ">
                                                    <input  class="form-control" type="text" id="nama_dpn" placeholder="Nama depan" name="nama_dpn" required>
                                                </div>

                                                <div class="form-group ">
                                                    <input  class="form-control" type="text" id="nama_blkg" placeholder="Nama belakang" name="nama_blkg" required>
                                                </div>

                                                <div class="form-group ">
                                                    <input  class="form-control" type="email" id="email" placeholder="Email" name="email_u" required>
                                                </div>
    
                                                <div class="form-group ">
                                                    <input  class="form-control" type="text" id="ptn" placeholder="Perguruan Tinggi" name="ptn" required>
                                                </div>

                                                <div class="form-group ">
                                                    <input  class="form-control" type="telno" placeholder="Nomor Hp" name="hp" required >
                                                </div>

                                                <div class="form-group ">
                                                    <input required="password" class="form-control" type="password" placeholder="Password" name="psw">
                                                </div>

                                                <div class="form-group">
                                                    <div>
                                                        <button class="btn btn-primary " name="submit" type="submit">
                                                            Tambah
                                                        </button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>



                        </div>
                    </div>
                </div>
  
</div>
              

<script>
// If user clicks anywhere outside of the modal, Modal will close

var modal = document.getElementById('modal-wrapper');
window.onclick = function(event) {
        if (event.target == modal) {
        modal.style.display = "none";
    }
}

</script>

<script type="text/javascript">
    var modal = document.getElementById('modal-wrapper-edit<?php echo $id_user?>');

      window.onclick = function(event) {
         var id = document.getElementById('edit'),
        if (event.target == modal) {
                 modal.style.display = "none";
         }
      } 
</script>

<script src="<?php echo base_url('assets/css/bootstrapvalidator.min.js.download'); ?>"></script>
<script type="text/javascript">
 
   $(document).ready(function() {
    $('#reg_form').bootstrapValidator({
        // To use feedback icons, ensure that you use Bootstrap v3.1.0 or later
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            first_name: {
                validators: {
                        stringLength: {
                        min: 2,
                    },
                        notEmpty: {
                        message: 'Please supply your first name'
                    }
                }
            },
             last_name: {
                validators: {
                     stringLength: {
                        min: 2,
                    },
                    notEmpty: {
                        message: 'Please supply your last name'
                    }
                }
            },
           
            phone: {
                validators: {
                    notEmpty: {
                        message: 'Please supply your phone number'
                    },
                    phone: {
                        country: 'US',
                        message: 'Please supply a vaild phone number with area code'
                    }
                }
            },
            address: {
                validators: {
                     stringLength: {
                        min: 8,
                    },
                    notEmpty: {
                        message: 'Please supply your street address'
                    }
                }
            },
            city: {
                validators: {
                     stringLength: {
                        min: 4,
                    },
                    notEmpty: {
                        message: 'Please supply your city'
                    }
                }
            },
            state: {
                validators: {
                    notEmpty: {
                        message: 'Please select your state'
                    }
                }
            },
            zip: {
                validators: {
                    notEmpty: {
                        message: 'Please supply your zip code'
                    },
                    zipCode: {
                        country: 'US',
                        message: 'Please supply a vaild zip code'
                    }
                }
            },
        comment: {
                validators: {
                      stringLength: {
                        min: 10,
                        max: 200,
                        message:'Please enter at least 10 characters and no more than 200'
                    },
                    notEmpty: {
                        message: 'Please supply a description about yourself'
                    }
                    }
                 }, 
     email: {
                validators: {
                    notEmpty: {
                        message: 'Please supply your email address'
                    },
                    emailAddress: {
                        message: 'Please supply a valid email address'
                    }
                }
            },
                    
    password: {
            validators: {
                identical: {
                    field: 'confirmPassword',
                    message: 'Confirm your password below - type same password please'
                }
            }
        },
        confirmPassword: {
            validators: {
                identical: {
                    field: 'password',
                    message: 'The password and its confirm are not the same'
                }
            }
         },
            
            
            }
        })
        
    
        .on('success.form.bv', function(e) {
            $('#success_message').slideDown({ opacity: "show" }, "slow") // Do something ...
                $('#reg_form').data('bootstrapValidator').resetForm();

            // Prevent form submission
            e.preventDefault();

            // Get the form instance
            var $form = $(e.target);

            // Get the BootstrapValidator instance
            var bv = $form.data('bootstrapValidator');

            // Use Ajax to submit form data
            $.post($form.attr('action'), $form.serialize(), function(result) {
                console.log(result);
            }, 'json');
        });
});


 
 </script>
